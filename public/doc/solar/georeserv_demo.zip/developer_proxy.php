<?php
/*
Connects to the NREL developer site with 
your api key and relays the result of the
query back.

This allows you to:

a) hide your api key on the server side.
b) get around javascript's limitations for cross-site XHR.

*/

require_once("class_http.php");


$api_key = '<my api_key>';

$devloper_prefix = 'http://developer.nrel.gov/api/';


if (!isset($_GET['site_url'])) {
    header("HTTP/1.0 400 Bad Request");
    echo "<h1>400 Bad Request</h1>";
    echo "proxy failed because site_url parameter is missing";
    exit();
}


$site = $_GET['site_url'];

//assemble the URL, including your API key

$url = $devloper_prefix.$site.'?api_key='.$api_key;

foreach ( $_GET as $key => $value ){
    if ($key != 'site_url'){
        $url = $url.'&'.$key.'='.urlencode($value);
    }
}

$req = new http();
$req->fetch($url);

$ary_headers = split("\n", $req->header);
foreach($ary_headers as $hdr) { header($hdr); }

echo $req->body;
?>