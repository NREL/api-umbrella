use LWP;
use HTTP::Cookies;
use HTTP::Request::Common qw(POST);
use HTTP::Request::Common qw(GET);

$api_key = 'DEMO_KEY';

$developer_prefix = 'http://developer.nrel.gov/api/';

$login_url = $developer_prefix . 'georeserv/login_handler?api_key=' . $api_key;

$geo_username = 'your_username';
$geo_password = 'your_password';

$cookie_jar = HTTP::Cookies->new(
    file => "$ENV{'HOME'}/lwp_cookies.dat",
    autosave => 1,
  );

$ua = LWP::UserAgent->new;
$ua->cookie_jar($cookie_jar);

#login to georeserv
my $req = POST $login_url, [login=>$geo_username, password=>$geo_password];

$response = $ua->request($req);

$data_url = $developer_prefix . 'georeserv/app/pvdaq/sites.json';

$data_url = $data_url . '?api_key=' . $api_key. '&system_id=13';

my $req = GET $data_url;

$response = $ua->request($req);

print "output: \n";
print $response->content;
print "\n";